/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modèle;

/**
 *
 * @author Junayet
 */
public interface Personne {
    public int getId();
    public String getNom();
    public String getPrenom();
    public String type_perso();
}
